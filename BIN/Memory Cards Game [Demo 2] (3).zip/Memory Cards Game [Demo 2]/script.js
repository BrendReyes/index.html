/*List of features needed:
  ❌ random math problems contents of cards
  ❌ difficulty scaling
  ❌ score reveal at the end of the game
  ✅ timer (with increment and decrement) 
  ✅ match and mismatch tracker
*/
const cards = document.querySelectorAll(".card"),
timeTag = document.querySelector(".time b"),
flipsTag = document.querySelector(".flips b"),
refreshBtn = document.querySelector(".details button"),
matchTag = document.querySelector(".matches b"),
mismatchTag = document.querySelector(".mismatches b");

let maxTime = 60;
let timeLeft = maxTime;
let flips = 0;
let matchedCard = 0;
let disableDeck = false;
let isPlaying = false;
let cardOne, cardTwo, timer;
let matches = 0;
let mismatches = 0;

//for win pop up alert
const openBtn = document.getElementById("openModal"); 
const closeBtn = document.getElementById("closeModal");
const modal = document.getElementById("modal");

//for lose pop up alert
const openBtn2 = document.getElementById("openModal2");
const closeBtn2 = document.getElementById("closeModal2");
const modal2 = document.getElementById("modal2");

function initTimer() {//timer countdown
  if(timeLeft <= 0) {

    setTimeout(() => {//delay before showing the pop up lose alert
      openBtn2.removeEventListener("click", openModal2);
        modal2.classList.add("open");
        closeBtn2.addEventListener("click", () => {
        modal2.classList.remove("open");
        shuffleCard();
      });
      }, 50);
      return clearInterval(timer);
  }
  timeLeft--;
  timeTag.innerText = timeLeft;
}

function flipCard({target: clickedCard}) {
  if(!isPlaying) {
      isPlaying = true;
      timer = setInterval(initTimer, 1000);
  }
  if(clickedCard !== cardOne && !disableDeck && timeLeft > 0) {
      flips++;
      flipsTag.innerText = flips;
      clickedCard.classList.add("flip");
      if(!cardOne) {
          //return the cardOne value to ClickedCard
          return cardOne = clickedCard;
      }
      cardTwo = clickedCard;
      disableDeck = true;
      let cardOneNum = cardOne.querySelector(".back-view h1").innerText,
      cardTwoNum = cardTwo.querySelector(".back-view h1").innerText;
      matchCards(cardOneNum, cardTwoNum); //function to check if the cards are the same
  }
}

function matchCards(num1, num2) {
  if(num1 === num2) { //if the 2 cards matched
      matchedCard++; //incremet match value by 1
      
      matches++; //counts the matches
      matchTag.innerText = matches;

      setTimeout(() => {
        timeLeft += 3; // plus 3s every match
        timeTag.innerText = timeLeft;
      }, 500);
      
      if(matchedCard == 8 && timeLeft > 0) {//if the user has matched all the cards 

        setTimeout(() => {//pop up alert 
        openBtn.removeEventListener("click", openModal);
        modal.classList.add("open");
        closeBtn.addEventListener("click", () => {
          modal.classList.remove("open");
          shuffleCard();
        });
      }, 250);

        return clearInterval(timer);    
      }
  
      cardOne.removeEventListener("click", flipCard);
      cardTwo.removeEventListener("click", flipCard);
      cardOne = cardTwo = ""; //setting both card value to blank
      return disableDeck = false;
  }
    //if the two cards did not match
  setTimeout(() => {
      //there will be shake effect 
      cardOne.classList.add("shake");
      cardTwo.classList.add("shake");

      mismatches++; //counts the mismatch
      mismatchTag.innerText = mismatches;

      setTimeout(() => {
        timeLeft -= 2; // minus 2s every mismatch
        timeTag.innerText = timeLeft;
        if(timeLeft < 0){
          timeLeft = 0;
          timeTag.innerText = timeLeft;         
        }
      }, 200);
  }, 400);

  setTimeout(() => {
      //removing shake and flip classes from both cards
      cardOne.classList.remove("shake", "flip");
      cardTwo.classList.remove("shake", "flip");
      cardOne = cardTwo = ""; //setting both card value to blank
      disableDeck = false;
  }, 1200);
}

function shuffleCard() {
  timeLeft = maxTime;
  flips = matchedCard = 0;
  cardOne = cardTwo = "";
  clearInterval(timer);
  timeTag.innerText = timeLeft;
  flipsTag.innerText = flips;
  matches = 0;
  mismatches = 0;
  matchTag.innerText = matches;
  mismatchTag.innerText = mismatches;
  disableDeck = isPlaying = false;

  let arr = [1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3, 4, 5, 6, 7, 8];

  arr.sort(() => Math.random() > 0.5 ? 1 : -1); //sorting array randomly

  cards.forEach((card, index) => {
      card.classList.remove("flip");
      let numTag = card.querySelector(".back-view h1");
      setTimeout(() => {
          numTag.innerText = arr[index]; //content of the card that comes from the array
      }, 500);
      card.addEventListener("click", flipCard);
  });
}

shuffleCard();

refreshBtn.addEventListener("click", shuffleCard);

cards.forEach(card => { //adding click events to all cards
  card.addEventListener("click", flipCard);
});


